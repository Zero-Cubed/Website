<!DOCTYPE html>
<html>
<head>
<style>


ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: center;
    display: inline-block;

}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 16px 18px;
    text-decoration: none;
}

a:hover:not(.active) {
    background-color: #111;
}

.active {
background-color:#;
}




.button {
    
    background-color: #000000; /* Green */
    border: none;
    color: white;
    padding: 35px 72px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 96px;
    margin: 4px 2px;
    cursor: pointer;
    position: absolute;
    right: 590px;
    top: 340px;
   border-radius: 5px; 
-moz-border-radius: 5px; 
-webkit-border-radius: 5px; 
border: 2px solid;
}

.button1 {font-size: 10px;}
.button2 {font-size: 12px;}
.button3 {font-size: 36px;}
.button4 {font-size: 20px;}
.button5 {font-size: 24px;}



</style>


</head>
<body bgcolor="">

<ul>
<center>
  <li><a href="index.php">Home</a></li>
  <li><a href="#news">Updates</a></li>
  <li><a href="register.php">Register</a></li>
  <li><a href="login.php">Login</a></li>
<center/>
</ul>


</body>
</html>

