<?php include 'Header.php';
?>

<html>

<head>
<style>
.button {
    
    background-color: #000000; /* Green */
    border: none;
    color: white;
    padding: 35px 72px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 96px;
    margin: 4px 2px;
    cursor: pointer;
    position: absolute;
    right: 590px;
    top: 340px;
   border-radius: 5px; 
-moz-border-radius: 5px; 
-webkit-border-radius: 5px; 
border: 2px solid;
}

.button1 {font-size: 10px;}
.button2 {font-size: 12px;}
.button3 {font-size: 36px;}
.button4 {font-size: 20px;}
.button5 {font-size: 24px;}

</style>

<head/>

<body>
</body>
</html>
